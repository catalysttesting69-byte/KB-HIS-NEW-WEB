<?php
/**
 * admin/login.php
 * ─────────────────────────────────────────────────────────────
 * EXACT UI REPLICA FROM ROOT PROJECT
 * ─────────────────────────────────────────────────────────────
 */

session_start();
require_once __DIR__ . '/../includes/config.php';

// If admin is already logged in, redirect to dashboard
if (!empty($_SESSION['admin_id'])) {
    header('Location: ' . BASE_URL . '/admin/dashboard.php');
    exit;
}

require_once __DIR__ . '/../includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } else {
        $stmt = $pdo->prepare("SELECT id, name, password_hash FROM users WHERE email = :email AND role = 'admin' LIMIT 1");
        $stmt->execute([':email' => $email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            $_SESSION['last_activity'] = time(); // Initialize activity
            header('Location: ' . BASE_URL . '/admin/dashboard.php');
            exit;
        } else {
            $error = 'Invalid email or password. Please try again.';
        }
    }
}

// Check for expiration message from redirect
if (isset($_GET['error']) && $_GET['error'] === 'session_expired') {
    $error = 'Your session has expired due to 30 minutes of inactivity. Please sign in again.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login — Zanzibar Safari</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --brand-dark: #0f172a;
            --brand-accent: #d4af37;
            --white: #ffffff;
            --text-muted: rgba(255, 255, 255, 0.6);
            --glass-bg: rgba(15, 23, 42, 0.85);
            --border: rgba(255, 255, 255, 0.1);
        }
        
        @keyframes slow-zoom {
            0% { transform: scale(1); }
            100% { transform: scale(1.1); }
        }

        body {
            font-family: 'Outfit', sans-serif;
            background: #050a08;
            min-height: 100vh;
            display: flex; 
            align-items: center; 
            justify-content: center; 
            padding: 20px;
            overflow: hidden;
            position: relative;
        }

        /* Cinematic Background Layer */
        .bg-container {
            position: absolute;
            inset: 0;
            z-index: -1;
            overflow: hidden;
        }

        .bg-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            animation: slow-zoom 20s infinite alternate ease-in-out;
            filter: brightness(0.6);
        }

        .bg-overlay {
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at center, transparent 0%, var(--brand-dark) 100%);
            opacity: 0.8;
        }

        .login-card {
            background: rgba(15, 23, 42, 0.75); /* More transparent for glass feel */
            backdrop-filter: blur(30px); /* Increased blur */
            -webkit-backdrop-filter: blur(30px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 40px; 
            padding: 40px 50px; /* Reduced vertical padding, increased horizontal */
            width: 100%; 
            max-width: 500px; /* Increased width */
            box-shadow: 0 50px 100px rgba(0, 0, 0, 0.6); 
            position: relative; 
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Glassy Round Logo */
        .logo-sphere {
            width: 100px;
            height: 100px;
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }
        
        .login-logo img {
            max-width: 85%; height: auto; 
            filter: drop-shadow(0 5px 10px rgba(0,0,0,0.4));
        }

        /* --- Hardened Input Fix for Autofill (Chrome/Safari) --- */
        input:-webkit-autofill,
        input:-webkit-autofill:hover, 
        input:-webkit-autofill:focus, 
        input:-webkit-autofill:active {
            -webkit-box-shadow: 0 0 0 1000px #0f172a inset !important; /* Force matches dark brand background */
            -webkit-text-fill-color: var(--white) !important;
            color: var(--white) !important;
            transition: background-color 5000s ease-in-out 0s;
        }

        .login-logo h1 { 
            color: var(--white); 
            font-size: 28px; 
            font-weight: 700; 
            letter-spacing: -0.5px;
            font-family: 'Outfit', sans-serif;
        }
        .login-logo p { 
            color: var(--brand-accent); 
            font-size: 11px; 
            text-transform: uppercase;
            letter-spacing: 3px;
            font-weight: 700;
            margin-top: 8px;
            opacity: 0.8;
        }

        .form-group { margin-bottom: 28px; }
        .form-group label { 
            display: block; 
            color: var(--text-muted); 
            font-size: 10px; 
            font-weight: 800; 
            margin-bottom: 12px; 
            text-transform: uppercase; 
            letter-spacing: 2px; 
        }
        
        .input-wrap { position: relative; }
        .input-wrap i:not(.toggle-password) { 
            position: absolute; 
            left: 20px; 
            top: 50%; 
            transform: translateY(-50%); 
            color: var(--brand-accent); 
            font-size: 18px; 
            opacity: 0.6;
        }
        
        .form-group input { 
            width: 100%; 
            background: rgba(255, 255, 255, 0.03); 
            border: 1px solid rgba(255, 255, 255, 0.1); 
            border-radius: 16px; 
            color: var(--white); 
            font-family: 'Outfit', sans-serif; 
            font-size: 16px; 
            padding: 16px 20px 16px 55px; 
            transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1); 
            outline: none; 
        }
        
        .form-group input:focus { 
            border-color: var(--brand-accent); 
            background: rgba(255, 255, 255, 0.08); 
            box-shadow: 0 0 0 1px var(--brand-accent);
        }

        .toggle-password { 
            position: absolute; 
            right: 20px; 
            top: 50%; 
            transform: translateY(-50%); 
            color: var(--text-muted); 
            cursor: pointer; 
            font-size: 18px;
            transition: color 0.3s;
        }
        
        .error-box { 
            background: rgba(239, 68, 68, 0.1); 
            border: 1px solid rgba(239, 68, 68, 0.2); 
            border-radius: 16px; 
            color: #f87171; 
            font-size: 14px; 
            padding: 16px; 
            margin-bottom: 30px; 
            display: flex; 
            align-items: center; 
            gap: 12px; 
        }

        .btn-login { 
            width: 100%; 
            background: var(--brand-accent); 
            color: var(--brand-dark); 
            border: none; 
            border-radius: 16px; 
            font-family: 'Outfit', sans-serif; 
            font-size: 16px; 
            font-weight: 800; 
            padding: 18px; 
            cursor: pointer; 
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
            margin-top: 10px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            gap: 12px; 
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .btn-login:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 15px 30px rgba(212, 175, 55, 0.3);
            background: #e5c158;
        }

        .back-link { text-align: center; margin-top: 40px; }
        .back-link a { 
            color: var(--text-muted); 
            font-size: 13px; 
            text-decoration: none; 
            transition: 0.3s; 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
            font-weight: 500;
        }
        .back-link a:hover { color: var(--brand-accent); }

        /* --- Mobile Responsiveness --- */
        @media (max-width: 480px) {
            .login-card {
                padding: 30px 25px;
                border-radius: 30px;
                margin: 10px;
            }
            .logo-sphere {
                width: 80px;
                height: 80px;
                margin-bottom: 15px;
            }
            .login-logo h1 {
                font-size: 22px;
            }
            .login-logo p {
                font-size: 9px;
                letter-spacing: 2px;
            }
            .btn-login {
                padding: 16px;
                font-size: 14px;
            }
            .form-group {
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>

<div class="bg-container">
    <div class="bg-overlay"></div>
    <img src="https://lh3.googleusercontent.com/d/1K2ACMKsW0UDIqHkvl3MlM4gBq_l1BXd3" class="bg-image" alt="Zanzibar">
</div>

<div class="login-card">
    <div class="login-logo">
        <div class="logo-sphere">
            <img src="../pictures/zanzibarSafarilogo.png" alt="Zanzibar Safari">
        </div>
        <h1>Admin Portal</h1>
        <p>Bespoke Island Tours</p>
    </div>
    
    <?php if ($error): ?>
        <div class="error-box"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Master Email</label>
            <div class="input-wrap">
                <i class="far fa-user"></i>
                <input type="email" name="email" placeholder="admin@zanzibar.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label>Security Key</label>
            <div class="input-wrap">
                <i class="fas fa-eye toggle-password" id="togglePassword"></i>
                <input type="password" id="password" name="password" placeholder="••••••••" required>
            </div>
        </div>
        <button type="submit" class="btn-login">
            <span>Access Dashboard</span>
            <i class="fas fa-arrow-right"></i>
        </button>
    </form>
    
    <div class="back-link">
        <a href="../index.html"><i class="fas fa-long-arrow-alt-left"></i> Return to Main Website</a>
    </div>
</div>

<script>
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('togglePassword');
    
    toggleIcon.addEventListener('click', () => {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            toggleIcon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    });
</script>
</body>
</html>
</body>
</html>
